package application;
import javafx.application.*;    
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Worker;
import javafx.scene.Group;
import javafx.scene.Scene; 
import javafx.scene.control.*; 
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.event.ActionEvent; 
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage; 
import javafx.scene.image.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import java.awt.Color;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;
import javax.swing.JLabel;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import netscape.javascript.JSObject;
public class GPACalc extends Application {
	private static Stage s1;
	private static Stage s2;
	private static Stage s3;
	private static Stage s4;
	private static Stage s5;
	public void start(Stage s) throws FileNotFoundException {
		s1 = s;
		s2 = s;
		s3 = s;
		s4 = s;
		s5 = s;
		s.setTitle("GPA Calculator");
		//creating layout manager
		StackPane rootNode = new StackPane();
		rootNode.setPrefSize(500, 500);
        
        // create a input stream 
        FileInputStream input1;

		input1 = new FileInputStream("Logo-1.png");
  
        // create a image
        Image i1 = new Image(input1); 
  
        // create a image View
        ImageView iw1 = new ImageView(i1);
  
        // create a label
        Label b1 = new Label("", iw1);
  
        // create a Flow pane
        FlowPane r1 = new FlowPane(); 
  
        // add password field 
        r1.getChildren().add(b1);
        
        iw1.setX(175);
        iw1.setY(0);
        
        
        final Text welcome = new Text("Welcome students of WW-P");
        rootNode.getChildren().add(welcome);
        welcome.setFont(Font.font("Verdana", 24));
        
        
        Button Freshman = new Button("Freshman");
        Button SJS = new Button("Sophomore, Junior, or Senior");
        
        rootNode.getChildren().addAll(Freshman, SJS);
        Freshman.setOnAction(new FreshmanHandler());
        SJS.setOnAction(new SJSHandler());
        
        final Text key = new Text("Key:" + "\n" + "-PE doesn't count for Weighted GPA; only for Unweighted." + "\n" + "-Pick your respective grade and fill out previous year" + "\n" + " gpa's if possible." + "\n" + "-Credits will automatically be filled." + "\n" + "-You can type the course name to find it in the list." + "\n" + "-You can find the cumulative GPA's from previous years" + "\n" +" when you go to Genesis -> Grading -> Grade History.");
        
        
        Freshman.setLayoutX(215);
        Freshman.setLayoutY(235);
        Freshman.setPrefSize(200, 45);
        
        SJS.setLayoutX(215);
        SJS.setLayoutY(290);
        SJS.setPrefSize(200, 45);
        
        welcome.setLayoutX(140);
        welcome.setLayoutY(220);
        
        key.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        key.setLayoutX(10);
        key.setLayoutY(350);
        
        
        
        Group root = new Group(iw1, welcome, Freshman, SJS, key);
        
        
        Scene myScene = new Scene(root, 600, 510);
        
		
		s.setScene(myScene);
		s.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}        		
	class FreshmanHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			StackPane rootNode = new StackPane();
			
			final Text course = new Text("Course: ");
	        rootNode.getChildren().add(course);
	        course.setFont(Font.font("Verdana", 18));
	        
	        final Text finalGrade = new Text("Final Grade: ");
	        rootNode.getChildren().add(finalGrade);
	        finalGrade.setFont(Font.font("Verdana", 18));
	        
	        
	        final Text finalCredits = new Text("Final Credits: ");
	        rootNode.getChildren().add(finalCredits);
	        finalCredits.setFont(Font.font("Verdana", 18));
	        
	        course.setLayoutX(20);
	        course.setLayoutY(20);
	        
	        finalGrade.setLayoutX(200);
	        finalGrade.setLayoutY(20);
	        
	        finalCredits.setLayoutX(335);
	        finalCredits.setLayoutY(20);
	        
	        final ComboBox course1 = new ComboBox();
	        course1.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course2 = new ComboBox();
	        course2.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course3 = new ComboBox();
	        course3.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course4 = new ComboBox();
	        course4.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course5 = new ComboBox();
	        course5.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP), Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course6 = new ComboBox();
	        course6.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth",
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        TextField course7 = new TextField();
	        course7.setEditable(false);
	        TextField course8 = new TextField();
	        course8.setEditable(false);
	        rootNode.getChildren().addAll(course1, course2, course3, course4, course5, course6, course7, course8);
			
	        course1.setLayoutX(20);
	        course1.setLayoutY(40);
	        course1.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course1);
	        
	        course2.setLayoutX(20);
	        course2.setLayoutY(80);
	        course2.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course2);
	        
	        course3.setLayoutX(20);
	        course3.setLayoutY(120);
	        course3.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course3);
	        
	        course4.setLayoutX(20);
	        course4.setLayoutY(160);
	        course4.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course4);
	        
	        course5.setLayoutX(20);
	        course5.setLayoutY(200);
	        course5.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course5);
	        
	        course6.setLayoutX(20);
	        course6.setLayoutY(240);
	        course6.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course6);
	        
	        course7.setLayoutX(20);
	        course7.setLayoutY(280);
	        course7.setPrefSize(165, 25);
	        
	        course8.setLayoutX(20);
	        course8.setLayoutY(320);
	        course8.setPrefSize(165, 25);
	        
	        final ComboBox grade1 = new ComboBox();
	        grade1.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade2 = new ComboBox();
	        grade2.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade3 = new ComboBox();
	        grade3.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade4 = new ComboBox();
	        grade4.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade5 = new ComboBox();
	        grade5.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade6 = new ComboBox();
	        grade6.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade7 = new ComboBox();
	        grade7.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade8 = new ComboBox();
	        grade8.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        
	        grade1.setLayoutX(210);
	        grade1.setLayoutY(40);
	        grade1.setPrefSize(80, 25);
	        
	        grade2.setLayoutX(210);
	        grade2.setLayoutY(80);
	        grade2.setPrefSize(80, 25);
	        
	        grade3.setLayoutX(210);
	        grade3.setLayoutY(120);
	        grade3.setPrefSize(80, 25);
	        
	        grade4.setLayoutX(210);
	        grade4.setLayoutY(160);
	        grade4.setPrefSize(80, 25);
	        
	        grade5.setLayoutX(210);
	        grade5.setLayoutY(200);
	        grade5.setPrefSize(80, 25);
	        
	        grade6.setLayoutX(210);
	        grade6.setLayoutY(240);
	        grade6.setPrefSize(80, 25);
	        
	        grade7.setLayoutX(210);
	        grade7.setLayoutY(280);
	        grade7.setPrefSize(80, 25);
	        
	        grade8.setLayoutX(210);
	        grade8.setLayoutY(320);
	        grade8.setPrefSize(80, 25);
	        
	        
	        TextField credits1 = new TextField();
	        credits1.setPrefSize(165, 25);
	        credits1.setEditable(false);
	        TextField credits2 = new TextField();
	        credits2.setPrefSize(165, 25);
	        credits2.setEditable(false);
	        TextField credits3 = new TextField();
	        credits3.setPrefSize(165, 25);
	        credits2.setEditable(false);
	        TextField credits4 = new TextField();
	        credits4.setPrefSize(165, 25);
	        credits4.setEditable(false);
	        TextField credits5 = new TextField();
	        credits5.setPrefSize(165, 25);
	        credits5.setEditable(false);
	        TextField credits6 = new TextField();
	        credits6.setPrefSize(165, 25);
	        credits6.setEditable(false);
	        TextField credits7 = new TextField();
	        credits7.setPrefSize(165, 25);
	        credits7.setEditable(false);
	        TextField credits8 = new TextField();
	        credits8.setPrefSize(165, 25);
	        credits8.setEditable(false);
	        
	        
	        rootNode.getChildren().addAll(credits1, credits2, credits3, credits4, credits5, credits6, credits7, credits8);
	        
	        credits1.setLayoutX(340);
	        credits1.setLayoutY(40);
	        
	        credits2.setLayoutX(340);
	        credits2.setLayoutY(80);
	        
	        credits3.setLayoutX(340);
	        credits3.setLayoutY(120);
	        
	        credits4.setLayoutX(340);
	        credits4.setLayoutY(160);
	        
	        credits5.setLayoutX(340);
	        credits5.setLayoutY(200);
	        
	        credits6.setLayoutX(340);
	        credits6.setLayoutY(240);
	        
	        credits7.setLayoutX(340);
	        credits7.setLayoutY(280);
	        
	        credits8.setLayoutX(340);
	        credits8.setLayoutY(320);
	        
	        
	        Button calculateGPA = new Button("Calculate GPA");
	        
	        rootNode.getChildren().add(calculateGPA);
	        calculateGPA.setLayoutX(200);
	        calculateGPA.setLayoutY(365);
	        calculateGPA.setPrefSize(225, 60);
	        
	        Text unWeightedGpa = new Text("Unweighted GPA: ");
	        unWeightedGpa.setFont(Font.font("Verdana", 24));
	        TextField unWeighted = new TextField();
	        rootNode.getChildren().addAll(unWeighted, unWeightedGpa);  
	        
	        unWeightedGpa.setLayoutX(525);
	        unWeightedGpa.setLayoutY(225);
	        unWeighted.setLayoutX(545);
	        unWeighted.setLayoutY(245);
	        
	        unWeighted.setEditable(false);
	        
	        Text weightedGpa = new Text("Weighted GPA: ");
	        weightedGpa.setFont(Font.font("Verdana", 24));
	        TextField weighted = new TextField();
	        rootNode.getChildren().addAll(weighted, weightedGpa);  
	        
	        weightedGpa.setLayoutX(535);
	        weightedGpa.setLayoutY(125);
	        weighted.setLayoutX(540);
	        weighted.setLayoutY(145);
	        
	        weighted.setEditable(false);
	        
	        
	        Button back = new Button("Back");
	        
	        rootNode.getChildren().add(back);
	        back.setLayoutX(600);
	        back.setLayoutY(390);
	        back.setPrefSize(140, 50);
	        
	        back.setOnAction(new EventHandler<ActionEvent>() {
	        	@Override
			    public void handle(ActionEvent e) {
	        		try {
						start(s5);
					} catch (FileNotFoundException e1) {
						
					}
	        	}
	        });
	        course7.setText("Physical Education");
	        credits7.setText("3.75");
	        course8.setText("Health/Driver's Education");
	        credits8.setText("1.25");
	        calculateGPA.setOnAction(new EventHandler<ActionEvent>() {
	        	@Override
			    public void handle(ActionEvent e) {
	        		String cf1 = (String) course1.getSelectionModel().getSelectedItem();
	    	        if(cf1.equals("Senior Practicum") || cf1.equals("Financial Literacy") || cf1.equals("Descriptive Astronomy") || cf1.equals("Genetics") || cf1.equals("ESL Tutorial")) {
	    	        	credits1.setText("2.5");
	    	        }else if(cf1.equals("AP Calculus AB") || cf1.equals("AP Calculus BC") || cf1.equals("Biology Honors") || cf1.equals("Chemistry") || cf1.equals("Chemistry Honors") || cf1.equals("Physics") || cf1.equals("Physics Honors") || cf1.equals("Human ANatomy & Physiology")) {
	    	        	credits1.setText("6.0");
	    	        }else if(cf1.equals("AP Biology") || cf1.equals("AP Chemistry") || cf1.equals("Advanced Topics in Physics Honors")){
	    	        	credits1.setText("7.0");
	    	        }else {
	    	        	credits1.setText("5.0");
	    	        }
	    	        String cf2 = (String) course2.getSelectionModel().getSelectedItem();
	    	        if(cf2.equals("Senior Practicum") || cf2.equals("Financial Literacy") || cf2.equals("Descriptive Astronomy") || cf2.equals("Genetics") || cf2.equals("ESL Tutorial")) {
	    	        	credits2.setText("2.5");
	    	        }else if(cf2.equals("AP Calculus AB") || cf2.equals("AP Calculus BC") || cf2.equals("Biology Honors") || cf2.equals("Chemistry") || cf2.equals("Chemistry Honors") || cf2.equals("Physics") || cf2.equals("Physics Honors") || cf2.equals("Human Anatomy & Physiology")) {
	    	        	credits2.setText("6.0");
	    	        }else if(cf2.equals("AP Biology") || cf2.equals("AP Chemistry") || cf2.equals("Advanced Topics in Physics Honors")){
	    	        	credits2.setText("7.0");
	    	        }else {
	    	        	credits2.setText("5.0");
	    	        }
	    	        String cf3 = (String) course3.getSelectionModel().getSelectedItem();
	    	        if(cf3.equals("Senior Practicum") || cf3.equals("Financial Literacy") || cf3.equals("Descriptive Astronomy") || cf3.equals("Genetics") || cf3.equals("ESL Tutorial")) {
	    	        	credits3.setText("2.5");
	    	        }else if(cf3.equals("AP Calculus AB") || cf3.equals("AP Calculus BC") || cf3.equals("Biology Honors") || cf3.equals("Chemistry") || cf3.equals("Chemistry Honors") || cf3.equals("Physics") || cf3.equals("Physics Honors") || cf3.equals("Human ANatomy & Physiology")) {
	    	        	credits3.setText("6.0");
	    	        }else if(cf3.equals("AP Biology") || cf3.equals("AP Chemistry") || cf3.equals("Advanced Topics in Physics Honors")){
	    	        	credits3.setText("7.0");
	    	        }else {
	    	        	credits3.setText("5.0");
	    	        }
	    	        String cf4 = (String) course4.getSelectionModel().getSelectedItem();
	    	        if(cf4.equals("Senior Practicum") || cf4.equals("Financial Literacy") || cf4.equals("Descriptive Astronomy") || cf4.equals("Genetics") || cf4.equals("ESL Tutorial")) {
	    	        	credits4.setText("2.5");
	    	        }else if(cf4.equals("AP Calculus AB") || cf4.equals("AP Calculus BC") || cf4.equals("Biology Honors") || cf4.equals("Chemistry") || cf4.equals("Chemistry Honors") || cf4.equals("Physics") || cf4.equals("Physics Honors") || cf4.equals("Human ANatomy & Physiology")) {
	    	        	credits4.setText("6.0");
	    	        }else if(cf4.equals("AP Biology") || cf4.equals("AP Chemistry") || cf4.equals("Advanced Topics in Physics Honors")){
	    	        	credits4.setText("7.0");
	    	        }else {
	    	        	credits4.setText("5.0");
	    	        }
	    	        String cf5 = (String) course5.getSelectionModel().getSelectedItem();
	    	        if(cf5.equals("Senior Practicum") || cf5.equals("Financial Literacy") || cf5.equals("Descriptive Astronomy") || cf5.equals("Genetics") || cf5.equals("ESL Tutorial")) {
	    	        	credits5.setText("2.5");
	    	        }else if(cf5.equals("AP Calculus AB") || cf5.equals("AP Calculus BC") || cf5.equals("Biology Honors") || cf5.equals("Chemistry") || cf5.equals("Chemistry Honors") || cf5.equals("Physics") || cf5.equals("Physics Honors") || cf5.equals("Human Anatomy & Physiology")) {
	    	        	credits5.setText("6.0");
	    	        }else if(cf5.equals("AP Biology") || cf5.equals("AP Chemistry") || cf5.equals("Advanced Topics in Physics Honors")){
	    	        	credits5.setText("7.0");
	    	        }else {
	    	        	credits5.setText("5.0");
	    	        }
	    	        String cf6 = (String) course6.getSelectionModel().getSelectedItem();
	    	        if(cf6.equals("Senior Practicum") || cf6.equals("Financial Literacy") || cf6.equals("Descriptive Astronomy") || cf6.equals("Genetics") || cf6.equals("ESL Tutorial")) {
	    	        	credits6.setText("2.5");
	    	        }else if(cf6.equals("AP Calculus AB") || cf6.equals("AP Calculus BC") || cf6.equals("Biology Honors") || cf6.equals("Chemistry") || cf6.equals("Chemistry Honors") || cf6.equals("Physics") || cf6.equals("Physics Honors") || cf6.equals("Human ANatomy & Physiology")) {
	    	        	credits6.setText("6.0");
	    	        }else if(cf6.equals("AP Biology") || cf6.equals("AP Chemistry") || cf6.equals("Advanced Topics in Physics Honors")){
	    	        	credits6.setText("7.0");
	    	        }else {
	    	        	credits6.setText("5.0");
	    	        }
	    	        
	    	        String wf1 = (String) grade1.getSelectionModel().getSelectedItem();
	    	        String ws1;
	    	        	if(wf1.equals("A")) {
		    	        	ws1 = "4";
		    	        }else if(wf1.equals("B")) {
		    	        	ws1 = "3";
		    	        }else if(wf1.equals("C")) {
		    	        	ws1 = "2";
		    	        }else if(wf1.equals("D")) {
		    	        	ws1 = "1";
		    	        }else {
		    	        	ws1 = "0";
		    	        }
	    	        	String wf2 = (String) grade2.getSelectionModel().getSelectedItem();
		    	        String ws2;
		    	        	if(wf2.equals("A")) {
			    	        	ws2 = "4";
			    	        }else if(wf2.equals("B")) {
			    	        	ws2 = "3";
			    	        }else if(wf2.equals("C")) {
			    	        	ws2 = "2";
			    	        }else if(wf2.equals("D")) {
			    	        	ws2 = "1";
			    	        }else {
			    	        	ws2 = "0";
			    	        }
		    	        	String wf3 = (String) grade3.getSelectionModel().getSelectedItem();
			    	        String ws3;
			    	        	if(wf3.equals("A")) {
				    	        	ws3 = "4";
				    	        }else if(wf3.equals("B")) {
				    	        	ws3 = "3";
				    	        }else if(wf3.equals("C")) {
				    	        	ws3 = "2";
				    	        }else if(wf3.equals("D")) {
				    	        	ws3 = "1";
				    	        }else {
				    	        	ws3 = "0";
				    	        }
			    	        	String wf4 = (String) grade4.getSelectionModel().getSelectedItem();
				    	        String ws4;
				    	        	if(wf4.equals("A")) {
					    	        	ws4 = "4";
					    	        }else if(wf4.equals("B")) {
					    	        	ws4 = "3";
					    	        }else if(wf4.equals("C")) {
					    	        	ws4 = "2";
					    	        }else if(wf4.equals("D")) {
					    	        	ws4 = "1";
					    	        }else {
					    	        	ws4 = "0";
					    	        }
				    	        	String wf5 = (String) grade5.getSelectionModel().getSelectedItem();
					    	        String ws5;
					    	        	if(wf5.equals("A")) {
						    	        	ws5 = "4";
						    	        }else if(wf5.equals("B")) {
						    	        	ws5 = "3";
						    	        }else if(wf5.equals("C")) {
						    	        	ws5 = "2";
						    	        }else if(wf5.equals("D")) {
						    	        	ws5 = "1";
						    	        }else {
						    	        	ws5 = "0";
						    	        }
					    	        	String wf6 = (String) grade6.getSelectionModel().getSelectedItem();
						    	        String ws6;
						    	        	if(wf6.equals("A")) {
							    	        	ws6 = "4";
							    	        }else if(wf6.equals("B")) {
							    	        	ws6 = "3";
							    	        }else if(wf6.equals("C")) {
							    	        	ws6 = "2";
							    	        }else if(wf6.equals("D")) {
							    	        	ws6 = "1";
							    	        }else {
							    	        	ws6 = "0";
							    	        }
						    	        	String wf7 = (String) grade7.getSelectionModel().getSelectedItem();
							    	        String ws7;
							    	        	if(wf7.equals("A")) {
								    	        	ws7 = "4";
								    	        }else if(wf7.equals("B")) {
								    	        	ws7 = "3";
								    	        }else if(wf7.equals("C")) {
								    	        	ws7 = "2";
								    	        }else if(wf7.equals("D")) {
								    	        	ws7 = "1";
								    	        }else {
								    	        	ws7 = "0";
								    	        }
							    	        	String wf8 = (String) grade8.getSelectionModel().getSelectedItem();
								    	        String ws8;
								    	        	if(wf8.equals("A")) {
									    	        	ws8 = "4";
									    	        }else if(wf8.equals("B")) {
									    	        	ws8 = "3";
									    	        }else if(wf8.equals("C")) {
									    	        	ws8 = "2";
									    	        }else if(wf8.equals("D")) {
									    	        	ws8 = "1";
									    	        }else {
									    	        	ws8 = "0";
									    	        }
	    	        
	        		DecimalFormat ft = new DecimalFormat("#.####");
	        		
	        		
	        		String cr1 = (String) credits1.getText();
	        		String cr2 = (String) credits2.getText();
	        		String cr3 = (String) credits3.getText();
	        		String cr4 = (String) credits4.getText();
	        		String cr5 = (String) credits5.getText();
	        		String cr6 = (String) credits6.getText();
	        		String cr7 = (String) credits7.getText();
	        		String cr8 = (String) credits8.getText();
	        		
	        		double c1 = Double.parseDouble(cr1);
	        		double c2 = Double.parseDouble(cr2);
	        		double c3 = Double.parseDouble(cr3);
	        		double c4 = Double.parseDouble(cr4);
	        		double c5 = Double.parseDouble(cr5);
	        		double c6 = Double.parseDouble(cr6);
	        		double c7 = Double.parseDouble(cr7);
	        		double c8 = Double.parseDouble(cr8);
	        		
	        		int w1 = Integer.parseInt(ws1);
	        		int w2 = Integer.parseInt(ws2);
	        		int w3 = Integer.parseInt(ws3);
	        		int w4 = Integer.parseInt(ws4);
	        		int w5 = Integer.parseInt(ws5);
	        		int w6 = Integer.parseInt(ws6);
	        		int w7 = Integer.parseInt(ws7);
	        		int w8 = Integer.parseInt(ws8);
	        		
	        		double q1 = w1 * c1;
	        		double q2 = w2 * c2;
	        		double q3 = w3 * c3;
	        		double q4 = w4 * c4;
	        		double q5 = w5 * c5;
	        		double q6 = w6 * c6;
	        		double q7 = w7 * c7;
	        		double q8 = w8 * c8;
	        		
	        		double tc = c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8;
	        		double tq = q1 + q2 + q3 + q4 + q5 + q6 + q7 + q8;
	        		double nf = tq / tc;
	        		String f = ft.format(nf);
	        		unWeighted.setText(f);
	        		
	        		String af1 = (String) grade1.getSelectionModel().getSelectedItem();
	    	        String as1;
	    	        if(cf1.contains("Honors") || cf1.contains("AP")) {
	    	        	if(af1.equals("A")) {
	    	        		as1 = "5";
	    	        	}else if(af1.equals("B")) {
	    	        		as1 = "4";
	    	        	}else if(af1.equals("C")) {
	    	        		as1 = "3";
	    	        	}else if(af1.equals("D")) {
	    	        		as1 = "2";
	    	        	}else {
	    	        		as1 = "0";
	    	        }
	    	        }else {
	    	        	if(af1.equals("A")) {
		    	        	as1 = "4";
		    	        }else if(af1.equals("B")) {
		    	        	as1 = "3";
		    	        }else if(af1.equals("C")) {
		    	        	as1 = "2";
		    	        }else if(af1.equals("D")) {
		    	        	as1 = "1";
		    	        }else {
		    	        	as1 = "0";
		    	        }
	    	        }
	    	        String af2 = (String) grade2.getSelectionModel().getSelectedItem();
	    	        String as2;
	    	        if(cf2.contains("Honors") || cf2.contains("AP")) {
	    	        	if(af2.equals("A")) {
	    	        		as2 = "5";
	    	        	}else if(af2.equals("B")) {
	    	        		as2 = "4";
	    	        	}else if(af2.equals("C")) {
	    	        		as2 = "3";
	    	        	}else if(af2.equals("D")) {
	    	        		as2 = "2";
	    	        	}else {
	    	        		as2 = "0";
	    	        }
	    	        }else {
	    	        	if(af2.equals("A")) {
		    	        	as2 = "4";
		    	        }else if(af2.equals("B")) {
		    	        	as2 = "3";
		    	        }else if(af2.equals("C")) {
		    	        	as2 = "2";
		    	        }else if(af2.equals("D")) {
		    	        	as2 = "1";
		    	        }else {
		    	        	as2 = "0";
		    	        }
	    	        }
	    	        String af3 = (String) grade3.getSelectionModel().getSelectedItem();
	    	        String as3;
	    	        if(cf3.contains("Honors") || cf3.contains("AP")) {
	    	        	if(af3.equals("A")) {
	    	        		as3 = "5";
	    	        	}else if(af3.equals("B")) {
	    	        		as3 = "4";
	    	        	}else if(af3.equals("C")) {
	    	        		as3 = "3";
	    	        	}else if(af3.equals("D")) {
	    	        		as3 = "2";
	    	        	}else {
	    	        		as3 = "0";
	    	        }
	    	        }else {
	    	        	if(af3.equals("A")) {
		    	        	as3 = "4";
		    	        }else if(af3.equals("B")) {
		    	        	as3 = "3";
		    	        }else if(af3.equals("C")) {
		    	        	as3 = "2";
		    	        }else if(af3.equals("D")) {
		    	        	as3 = "1";
		    	        }else {
		    	        	as3 = "0";
		    	        }
	    	        }
	    	        String af4 = (String) grade4.getSelectionModel().getSelectedItem();
	    	        String as4;
	    	        if(cf4.contains("Honors") || cf4.contains("AP")) {
	    	        	if(af4.equals("A")) {
	    	        		as4 = "5";
	    	        	}else if(af4.equals("B")) {
	    	        		as4 = "4";
	    	        	}else if(af4.equals("C")) {
	    	        		as4 = "3";
	    	        	}else if(af4.equals("D")) {
	    	        		as4 = "2";
	    	        	}else {
	    	        		as4 = "0";
	    	        }
	    	        }else {
	    	        	if(af4.equals("A")) {
		    	        	as4 = "4";
		    	        }else if(af4.equals("B")) {
		    	        	as4 = "3";
		    	        }else if(af4.equals("C")) {
		    	        	as4 = "2";
		    	        }else if(af4.equals("D")) {
		    	        	as4 = "1";
		    	        }else {
		    	        	as4 = "0";
		    	        }
	    	        }
	    	        String af5 = (String) grade5.getSelectionModel().getSelectedItem();
	    	        String as5;
	    	        if(cf5.contains("Honors") || cf5.contains("AP")) {
	    	        	if(af5.equals("A")) {
	    	        		as5 = "5";
	    	        	}else if(af5.equals("B")) {
	    	        		as5 = "4";
	    	        	}else if(af5.equals("C")) {
	    	        		as5 = "3";
	    	        	}else if(af5.equals("D")) {
	    	        		as5 = "2";
	    	        	}else {
	    	        		as5 = "0";
	    	        }
	    	        }else {
	    	        	if(af5.equals("A")) {
		    	        	as5 = "4";
		    	        }else if(af5.equals("B")) {
		    	        	as5 = "3";
		    	        }else if(af5.equals("C")) {
		    	        	as5 = "2";
		    	        }else if(af5.equals("D")) {
		    	        	as5 = "1";
		    	        }else {
		    	        	as5 = "0";
		    	        }
	    	        }
	    	        String af6 = (String) grade6.getSelectionModel().getSelectedItem();
	    	        String as6;
	    	        if(cf6.contains("Honors") || cf6.contains("AP")) {
	    	        	if(af6.equals("A")) {
	    	        		as6 = "5";
	    	        	}else if(af6.equals("B")) {
	    	        		as6 = "4";
	    	        	}else if(af6.equals("C")) {
	    	        		as6 = "3";
	    	        	}else if(af6.equals("D")) {
	    	        		as6 = "2";
	    	        	}else {
	    	        		as6 = "0";
	    	        }
	    	        }else {
	    	        	if(af6.equals("A")) {
		    	        	as6 = "4";
		    	        }else if(af6.equals("B")) {
		    	        	as6 = "3";
		    	        }else if(af6.equals("C")) {
		    	        	as6 = "2";
		    	        }else if(af6.equals("D")) {
		    	        	as6 = "1";
		    	        }else {
		    	        	as6 = "0";
		    	        }
	    	        }
	    	        String af8 = (String) grade8.getSelectionModel().getSelectedItem();
	    	        String as8;
	    	        	if(af8.equals("A")) {
		    	        	as8 = "4";
		    	        }else if(af8.equals("B")) {
		    	        	as8 = "3";
		    	        }else if(af8.equals("C")) {
		    	        	as8 = "2";
		    	        }else if(af8.equals("D")) {
		    	        	as8 = "1";
		    	        }else {
		    	        	as8 = "0";
		    	        }

		        		String cwr1 = (String) credits1.getText();
		        		String cwr2 = (String) credits2.getText();
		        		String cwr3 = (String) credits3.getText();
		        		String cwr4 = (String) credits4.getText();
		        		String cwr5 = (String) credits5.getText();
		        		String cwr6 = (String) credits6.getText();
		        		String cwr8 = (String) credits8.getText();
		        		
		        		double cw1 = Double.parseDouble(cwr1);
		        		double cw2 = Double.parseDouble(cwr2);
		        		double cw3 = Double.parseDouble(cwr3);
		        		double cw4 = Double.parseDouble(cwr4);
		        		double cw5 = Double.parseDouble(cwr5);
		        		double cw6 = Double.parseDouble(cwr6);
		        		double cw8 = Double.parseDouble(cwr8);
		        		
		        		int ww1 = Integer.parseInt(as1);
		        		int ww2 = Integer.parseInt(as2);
		        		int ww3 = Integer.parseInt(as3);
		        		int ww4 = Integer.parseInt(as4);
		        		int ww5 = Integer.parseInt(as5);
		        		int ww6 = Integer.parseInt(as6);
		        		int ww8 = Integer.parseInt(as8);
		        		
		        		double qw1 = ww1 * cw1;
		        		double qw2 = ww2 * cw2;
		        		double qw3 = ww3 * cw3;
		        		double qw4 = ww4 * cw4;
		        		double qw5 = ww5 * cw5;
		        		double qw6 = ww6 * cw6;
		        		double qw8 = ww8 * cw8;
		        		
		        		double twc = cw1 + cw2 + cw3 + cw4 + cw5 + cw6 + cw8;
		        		double twq = qw1 + qw2 + qw3 + qw4 + qw5 + qw6 + qw8;
		        		double nwf = twq / twc;
		        		String f1 = ft.format(nwf);
		        		weighted.setText(f1);
	        	}
	        });
	        
			Group root = new Group(course, finalGrade, finalCredits, course1, course2, course3, course4, course5, course6, course7, course8, grade1, grade2, grade3, grade4, grade5, grade6, grade7, grade8, credits1, credits2, credits3, credits4, credits5, credits6, credits7, credits8, calculateGPA, unWeightedGpa, unWeighted, weighted, weightedGpa, back);
			Scene scene1 = new Scene(root, 750, 450);
			
			GPACalc.getStage1().setScene(scene1);
			
			s1.show();
		}
	}
	class SJSHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			StackPane rootNode = new StackPane();
			
			final Text course = new Text("Course: ");
	        rootNode.getChildren().add(course);
	        course.setFont(Font.font("Verdana", 18));
	        
	        final Text finalGrade = new Text("Final Grade: ");
	        rootNode.getChildren().add(finalGrade);
	        finalGrade.setFont(Font.font("Verdana", 18));
	        
	        
	        final Text finalCredits = new Text("Final Credits: ");
	        rootNode.getChildren().add(finalCredits);
	        finalCredits.setFont(Font.font("Verdana", 18));
	        
	        course.setLayoutX(20);
	        course.setLayoutY(20);
	        
	        finalGrade.setLayoutX(200);
	        finalGrade.setLayoutY(20);
	        
	        finalCredits.setLayoutX(335);
	        finalCredits.setLayoutY(20);
	        
	        final ComboBox course1 = new ComboBox();
	        course1.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course2 = new ComboBox();
	        course2.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course3 = new ComboBox();
	        course3.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course4 = new ComboBox();
	        course4.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course5 = new ComboBox();
	        course5.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth", 
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP), Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        final ComboBox course6 = new ComboBox();
	        course6.getItems().addAll(
	        	"Art Foundation", "Drawing and Painting I", "Drawing and Painting II", "Sculpture & Ceramics", "Printmaking",
	        	"Computer Art & Design", "Photography", "AP Studio Art", "AP Art History", "Financial Literacy", "Accounting",
	        	"Marketing", "Digital Media", "Introduction to Computer Programming & Mobile App/Game Design", "Digital Communication",
	        	"AP Computer Science A", "AP Computer Science Principles", "Advanced Topics in Computer Science Honors", 
	        	"Engineering Design and Fabrication", "Principles of Engineering", "Graphic Engineering", "Creative Design", "Advanced Clothing Construction", "Culinary Arts",
	        	"International Foods", "Cretaive Cooking & Catering", "Child Growth and Development", "Youth Teaching Youth",
	        	"Fundamentals of Sports Medicine", "LA I", "LA I Honors", "LA II", "LA II Honors", "LA III", "LA III Honors", "AP Language & Composition", "AP Literature & Composition", "LA IV", "LA IV Honors",
	        	"Algebra 1", "Algebra 2", "Advanced Algebra 2", "Advanced Algebra 2 Honors", "Geometry", "Geometry Honors", "Geomerty Honors and Accelerated", "Algebra & Trignometry", "Pre-Calculus", 
	        	"Pre-Calculus Honors", "Pre-Calculus Honors & Accelerated", "Calculus Honors", "AP Calculus AB", "AP Calculus BC", "Multivariable Calculus", 
	        	"Statistics", "AP Statistics", "Broadcast Writing", "Advanced Broadcast Writing I/II", "TV Production", "Journalism", "Advanced Journalism Honors I/II", "Music Theory I", "Music Theory II", "Music Technology", "Chorale",
	        	"Concert Choir (CP)", "Concert Choir (Honors)", "Chamber Choir (Honors)", "Concert Band", "Symphonic Band (CP)", "Symphonic Band (Honors)", "Wind Ensemble (Honors)", "String Ensemble", "Symphony Orchestra (CP or Honors)", "Philharmonic Orchestra (Honors)", 
	        	"Biology", "Biology Honors", "Chemistry", "Chemistry Honors", "AP Biology", "AP Chemistry", "Physics", "Physics Honors", "Advanced Topics in Physics Honors", "Environmental Science", "Forensic Science", "Human Anatomy & Physiology", "AP Environmental Science", 
	        	"Descriptive Astronomy", "Genetics", "World History", "World History Honors", "American Studies I", "American Studies I Honors", "American Studies II", "American Studies II Honors", "International Business & Cultures", "Human Behavior", "Legal and Political Experiences (IPLE)",
	        	"Economics/Social Problems in American Society", "Multicultural Studies", "AP United States History", "AP European History", "AP American Government", "AP Comparative Government and Global Studies", "AP Psychology",
	        	"AP Microeconomics", "Theatre Arts", "An Intro to Spanish Communication & Culture", "Spanish Language & Cultural Study", "Spanish 1", "Spanish 2", "Spanish 3", "Spanish 3 Honors", "Spanish 4", "Spanish 4 Honors", "Spanish 5", "Conversations in Spanish", "Honors Spanish Cultural Studies",
	        	"AP Spanish Language", "AP Spanish Literature", "French 1", "French 2", "French 3", "French 3 Honors", "French 4", "French 4 Honors", "French 5", "French 5 Honors", "AP French Language", "German 1", "German 2", "German 3", "German 4 Honors", "German 5 Honors", "AP German Language", "Chinese 1",
	        	"Chinese 2", "Chinese 3", "Chinese 4 Honors", "Chinese 5 Honors", "AP Chinese Language", "Language Arts ESL I", "Language Arts ESL II", "Language Arts ESL III" , "Language Arts ESL IV" , "World History ESL", "American Studies I ESL", "American Studies II ESL", "Science I ESL 5", 
	        	"Science II ESL (Biology)", "ESL Tutorial", "Princeton University Course", "Student Research in the Humanities", "Student Research in the Sciences", "Senior Practicum", "Senior Internship", "");
	        TextField course7 = new TextField();
	        course7.setEditable(false);
	        TextField course8 = new TextField();
	        course8.setEditable(false);
	        rootNode.getChildren().addAll(course1, course2, course3, course4, course5, course6, course7, course8);
			
	        course1.setLayoutX(20);
	        course1.setLayoutY(40);
	        course1.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course1);
	        
	        course2.setLayoutX(20);
	        course2.setLayoutY(80);
	        course2.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course2);
	        
	        course3.setLayoutX(20);
	        course3.setLayoutY(120);
	        course3.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course3);
	        
	        course4.setLayoutX(20);
	        course4.setLayoutY(160);
	        course4.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course4);
	        
	        course5.setLayoutX(20);
	        course5.setLayoutY(200);
	        course5.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course5);
	        
	        course6.setLayoutX(20);
	        course6.setLayoutY(240);
	        course6.setPrefSize(165, 25);
	        new AutoCompleteComboBoxListener<>(course6);
	        
	        course7.setLayoutX(20);
	        course7.setLayoutY(280);
	        course7.setPrefSize(165, 25);
	        
	        course8.setLayoutX(20);
	        course8.setLayoutY(320);
	        course8.setPrefSize(165, 25);
	        
	        final ComboBox grade1 = new ComboBox();
	        grade1.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade2 = new ComboBox();
	        grade2.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade3 = new ComboBox();
	        grade3.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade4 = new ComboBox();
	        grade4.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade5 = new ComboBox();
	        grade5.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade6 = new ComboBox();
	        grade6.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade7 = new ComboBox();
	        grade7.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        final ComboBox grade8 = new ComboBox();
	        grade8.getItems().addAll(
	           "A","B", "C", "D", "F"
	        );
	        
	        grade1.setLayoutX(210);
	        grade1.setLayoutY(40);
	        grade1.setPrefSize(80, 25);
	        
	        grade2.setLayoutX(210);
	        grade2.setLayoutY(80);
	        grade2.setPrefSize(80, 25);
	        
	        grade3.setLayoutX(210);
	        grade3.setLayoutY(120);
	        grade3.setPrefSize(80, 25);
	        
	        grade4.setLayoutX(210);
	        grade4.setLayoutY(160);
	        grade4.setPrefSize(80, 25);
	        
	        grade5.setLayoutX(210);
	        grade5.setLayoutY(200);
	        grade5.setPrefSize(80, 25);
	        
	        grade6.setLayoutX(210);
	        grade6.setLayoutY(240);
	        grade6.setPrefSize(80, 25);
	        
	        grade7.setLayoutX(210);
	        grade7.setLayoutY(280);
	        grade7.setPrefSize(80, 25);
	        
	        grade8.setLayoutX(210);
	        grade8.setLayoutY(320);
	        grade8.setPrefSize(80, 25);
	        
	        
	        TextField credits1 = new TextField();
	        credits1.setPrefSize(165, 25);
	        credits1.setEditable(false);
	        TextField credits2 = new TextField();
	        credits2.setPrefSize(165, 25);
	        credits2.setEditable(false);
	        TextField credits3 = new TextField();
	        credits3.setPrefSize(165, 25);
	        credits2.setEditable(false);
	        TextField credits4 = new TextField();
	        credits4.setPrefSize(165, 25);
	        credits4.setEditable(false);
	        TextField credits5 = new TextField();
	        credits5.setPrefSize(165, 25);
	        credits5.setEditable(false);
	        TextField credits6 = new TextField();
	        credits6.setPrefSize(165, 25);
	        credits6.setEditable(false);
	        TextField credits7 = new TextField();
	        credits7.setPrefSize(165, 25);
	        credits7.setEditable(false);
	        TextField credits8 = new TextField();
	        credits8.setPrefSize(165, 25);
	        credits8.setEditable(false);
	        
	        
	        rootNode.getChildren().addAll(credits1, credits2, credits3, credits4, credits5, credits6, credits7, credits8);
	        
	        credits1.setLayoutX(340);
	        credits1.setLayoutY(40);
	        
	        credits2.setLayoutX(340);
	        credits2.setLayoutY(80);
	        
	        credits3.setLayoutX(340);
	        credits3.setLayoutY(120);
	        
	        credits4.setLayoutX(340);
	        credits4.setLayoutY(160);
	        
	        credits5.setLayoutX(340);
	        credits5.setLayoutY(200);
	        
	        credits6.setLayoutX(340);
	        credits6.setLayoutY(240);
	        
	        credits7.setLayoutX(340);
	        credits7.setLayoutY(280);
	        
	        credits8.setLayoutX(340);
	        credits8.setLayoutY(320);
	        
	        
	        Button calculateGPA = new Button("Calculate GPA");
	        
	        rootNode.getChildren().add(calculateGPA);
	        calculateGPA.setLayoutX(520);
	        calculateGPA.setLayoutY(285);
	        calculateGPA.setPrefSize(225, 60);
	        
	        Text unWeightedGpa = new Text("Unweighted GPA: ");
	        unWeightedGpa.setFont(Font.font("Verdana", 24));
	        TextField unWeighted = new TextField();
	        rootNode.getChildren().addAll(unWeighted, unWeightedGpa);  
	        
	        unWeightedGpa.setLayoutX(525);
	        unWeightedGpa.setLayoutY(215);
	        unWeighted.setLayoutX(545);
	        unWeighted.setLayoutY(235);
	        
	        unWeighted.setEditable(false);
	        
	        Text weightedGpa = new Text("Weighted GPA: ");
	        weightedGpa.setFont(Font.font("Verdana", 24));
	        TextField weighted = new TextField();
	        rootNode.getChildren().addAll(weighted, weightedGpa);  
	        
	        weightedGpa.setLayoutX(535);
	        weightedGpa.setLayoutY(125);
	        weighted.setLayoutX(540);
	        weighted.setLayoutY(145);
	        
	        weighted.setEditable(false);
	        
	        Text fweighted = new Text("Cumulative Weighted GPA:");
	        TextField ftweighted = new TextField();
	        fweighted.setFont(Font.font("Verdana", 20));
	        Text funweighted = new Text("Cumulative Unweighted GPA:");
	        TextField ftunweighted = new TextField();
	        funweighted.setFont(Font.font("Verdana", 20));
	        rootNode.getChildren().addAll(fweighted, funweighted);
	        
	        fweighted.setLayoutX(10);
	        fweighted.setLayoutY(370);
	        ftweighted.setLayoutX(10);
	        ftweighted.setLayoutY(380);
	        
	        funweighted.setLayoutX(10);
	        funweighted.setLayoutY(430);
	        ftunweighted.setLayoutX(10);
	        ftunweighted.setLayoutY(440);
	        Button back = new Button("Back");
	        
	        rootNode.getChildren().add(back);
	        back.setLayoutX(600);
	        back.setLayoutY(440);
	        back.setPrefSize(140, 50);
	        
	        back.setOnAction(new EventHandler<ActionEvent>() {
	        	@Override
			    public void handle(ActionEvent e) {
	        		try {
						start(s5);
					} catch (FileNotFoundException e1) {
						
					}
	        	}
	        });
	        course7.setText("Physical Education");
	        credits7.setText("3.75");
	        course8.setText("Health/Driver's Education");
	        credits8.setText("1.25");
	        calculateGPA.setOnAction(new EventHandler<ActionEvent>() {
	        	@Override
			    public void handle(ActionEvent e) {
	        		String cf1 = (String) course1.getSelectionModel().getSelectedItem();
	    	        if(cf1.equals("Senior Practicum") || cf1.equals("Financial Literacy") || cf1.equals("Descriptive Astronomy") || cf1.equals("Genetics") || cf1.equals("ESL Tutorial")) {
	    	        	credits1.setText("2.5");
	    	        }else if(cf1.equals("AP Calculus AB") || cf1.equals("AP Calculus BC") || cf1.equals("Biology Honors") || cf1.equals("Chemistry") || cf1.equals("Chemistry Honors") || cf1.equals("Physics") || cf1.equals("Physics Honors") || cf1.equals("Human ANatomy & Physiology")) {
	    	        	credits1.setText("6.0");
	    	        }else if(cf1.equals("AP Biology") || cf1.equals("AP Chemistry") || cf1.equals("Advanced Topics in Physics Honors")){
	    	        	credits1.setText("7.0");
	    	        }else {
	    	        	credits1.setText("5.0");
	    	        }
	    	        String cf2 = (String) course2.getSelectionModel().getSelectedItem();
	    	        if(cf2.equals("Senior Practicum") || cf2.equals("Financial Literacy") || cf2.equals("Descriptive Astronomy") || cf2.equals("Genetics") || cf2.equals("ESL Tutorial")) {
	    	        	credits2.setText("2.5");
	    	        }else if(cf2.equals("AP Calculus AB") || cf2.equals("AP Calculus BC") || cf2.equals("Biology Honors") || cf2.equals("Chemistry") || cf2.equals("Chemistry Honors") || cf2.equals("Physics") || cf2.equals("Physics Honors") || cf2.equals("Human Anatomy & Physiology")) {
	    	        	credits2.setText("6.0");
	    	        }else if(cf2.equals("AP Biology") || cf2.equals("AP Chemistry") || cf2.equals("Advanced Topics in Physics Honors")){
	    	        	credits2.setText("7.0");
	    	        }else {
	    	        	credits2.setText("5.0");
	    	        }
	    	        String cf3 = (String) course3.getSelectionModel().getSelectedItem();
	    	        if(cf3.equals("Senior Practicum") || cf3.equals("Financial Literacy") || cf3.equals("Descriptive Astronomy") || cf3.equals("Genetics") || cf3.equals("ESL Tutorial")) {
	    	        	credits3.setText("2.5");
	    	        }else if(cf3.equals("AP Calculus AB") || cf3.equals("AP Calculus BC") || cf3.equals("Biology Honors") || cf3.equals("Chemistry") || cf3.equals("Chemistry Honors") || cf3.equals("Physics") || cf3.equals("Physics Honors") || cf3.equals("Human ANatomy & Physiology")) {
	    	        	credits3.setText("6.0");
	    	        }else if(cf3.equals("AP Biology") || cf3.equals("AP Chemistry") || cf3.equals("Advanced Topics in Physics Honors")){
	    	        	credits3.setText("7.0");
	    	        }else {
	    	        	credits3.setText("5.0");
	    	        }
	    	        String cf4 = (String) course4.getSelectionModel().getSelectedItem();
	    	        if(cf4.equals("Senior Practicum") || cf4.equals("Financial Literacy") || cf4.equals("Descriptive Astronomy") || cf4.equals("Genetics") || cf4.equals("ESL Tutorial")) {
	    	        	credits4.setText("2.5");
	    	        }else if(cf4.equals("AP Calculus AB") || cf4.equals("AP Calculus BC") || cf4.equals("Biology Honors") || cf4.equals("Chemistry") || cf4.equals("Chemistry Honors") || cf4.equals("Physics") || cf4.equals("Physics Honors") || cf4.equals("Human ANatomy & Physiology")) {
	    	        	credits4.setText("6.0");
	    	        }else if(cf4.equals("AP Biology") || cf4.equals("AP Chemistry") || cf4.equals("Advanced Topics in Physics Honors")){
	    	        	credits4.setText("7.0");
	    	        }else {
	    	        	credits4.setText("5.0");
	    	        }
	    	        String cf5 = (String) course5.getSelectionModel().getSelectedItem();
	    	        if(cf5.equals("Senior Practicum") || cf5.equals("Financial Literacy") || cf5.equals("Descriptive Astronomy") || cf5.equals("Genetics") || cf5.equals("ESL Tutorial")) {
	    	        	credits5.setText("2.5");
	    	        }else if(cf5.equals("AP Calculus AB") || cf5.equals("AP Calculus BC") || cf5.equals("Biology Honors") || cf5.equals("Chemistry") || cf5.equals("Chemistry Honors") || cf5.equals("Physics") || cf5.equals("Physics Honors") || cf5.equals("Human Anatomy & Physiology")) {
	    	        	credits5.setText("6.0");
	    	        }else if(cf5.equals("AP Biology") || cf5.equals("AP Chemistry") || cf5.equals("Advanced Topics in Physics Honors")){
	    	        	credits5.setText("7.0");
	    	        }else {
	    	        	credits5.setText("5.0");
	    	        }
	    	        String cf6 = (String) course6.getSelectionModel().getSelectedItem();
	    	        if(cf6.equals("Senior Practicum") || cf6.equals("Financial Literacy") || cf6.equals("Descriptive Astronomy") || cf6.equals("Genetics") || cf6.equals("ESL Tutorial")) {
	    	        	credits6.setText("2.5");
	    	        }else if(cf6.equals("AP Calculus AB") || cf6.equals("AP Calculus BC") || cf6.equals("Biology Honors") || cf6.equals("Chemistry") || cf6.equals("Chemistry Honors") || cf6.equals("Physics") || cf6.equals("Physics Honors") || cf6.equals("Human ANatomy & Physiology")) {
	    	        	credits6.setText("6.0");
	    	        }else if(cf6.equals("AP Biology") || cf6.equals("AP Chemistry") || cf6.equals("Advanced Topics in Physics Honors")){
	    	        	credits6.setText("7.0");
	    	        }else {
	    	        	credits6.setText("5.0");
	    	        }
	    	        
	    	        String wf1 = (String) grade1.getSelectionModel().getSelectedItem();
	    	        String ws1;
	    	        	if(wf1.equals("A")) {
		    	        	ws1 = "4";
		    	        }else if(wf1.equals("B")) {
		    	        	ws1 = "3";
		    	        }else if(wf1.equals("C")) {
		    	        	ws1 = "2";
		    	        }else if(wf1.equals("D")) {
		    	        	ws1 = "1";
		    	        }else {
		    	        	ws1 = "0";
		    	        }
	    	        	String wf2 = (String) grade2.getSelectionModel().getSelectedItem();
		    	        String ws2;
		    	        	if(wf2.equals("A")) {
			    	        	ws2 = "4";
			    	        }else if(wf2.equals("B")) {
			    	        	ws2 = "3";
			    	        }else if(wf2.equals("C")) {
			    	        	ws2 = "2";
			    	        }else if(wf2.equals("D")) {
			    	        	ws2 = "1";
			    	        }else {
			    	        	ws2 = "0";
			    	        }
		    	        	String wf3 = (String) grade3.getSelectionModel().getSelectedItem();
			    	        String ws3;
			    	        	if(wf3.equals("A")) {
				    	        	ws3 = "4";
				    	        }else if(wf3.equals("B")) {
				    	        	ws3 = "3";
				    	        }else if(wf3.equals("C")) {
				    	        	ws3 = "2";
				    	        }else if(wf3.equals("D")) {
				    	        	ws3 = "1";
				    	        }else {
				    	        	ws3 = "0";
				    	        }
			    	        	String wf4 = (String) grade4.getSelectionModel().getSelectedItem();
				    	        String ws4;
				    	        	if(wf4.equals("A")) {
					    	        	ws4 = "4";
					    	        }else if(wf4.equals("B")) {
					    	        	ws4 = "3";
					    	        }else if(wf4.equals("C")) {
					    	        	ws4 = "2";
					    	        }else if(wf4.equals("D")) {
					    	        	ws4 = "1";
					    	        }else {
					    	        	ws4 = "0";
					    	        }
				    	        	String wf5 = (String) grade5.getSelectionModel().getSelectedItem();
					    	        String ws5;
					    	        	if(wf5.equals("A")) {
						    	        	ws5 = "4";
						    	        }else if(wf5.equals("B")) {
						    	        	ws5 = "3";
						    	        }else if(wf5.equals("C")) {
						    	        	ws5 = "2";
						    	        }else if(wf5.equals("D")) {
						    	        	ws5 = "1";
						    	        }else {
						    	        	ws5 = "0";
						    	        }
					    	        	String wf6 = (String) grade6.getSelectionModel().getSelectedItem();
						    	        String ws6;
						    	        	if(wf6.equals("A")) {
							    	        	ws6 = "4";
							    	        }else if(wf6.equals("B")) {
							    	        	ws6 = "3";
							    	        }else if(wf6.equals("C")) {
							    	        	ws6 = "2";
							    	        }else if(wf6.equals("D")) {
							    	        	ws6 = "1";
							    	        }else {
							    	        	ws6 = "0";
							    	        }
						    	        	String wf7 = (String) grade7.getSelectionModel().getSelectedItem();
							    	        String ws7;
							    	        	if(wf7.equals("A")) {
								    	        	ws7 = "4";
								    	        }else if(wf7.equals("B")) {
								    	        	ws7 = "3";
								    	        }else if(wf7.equals("C")) {
								    	        	ws7 = "2";
								    	        }else if(wf7.equals("D")) {
								    	        	ws7 = "1";
								    	        }else {
								    	        	ws7 = "0";
								    	        }
							    	        	String wf8 = (String) grade8.getSelectionModel().getSelectedItem();
								    	        String ws8;
								    	        	if(wf8.equals("A")) {
									    	        	ws8 = "4";
									    	        }else if(wf8.equals("B")) {
									    	        	ws8 = "3";
									    	        }else if(wf8.equals("C")) {
									    	        	ws8 = "2";
									    	        }else if(wf8.equals("D")) {
									    	        	ws8 = "1";
									    	        }else {
									    	        	ws8 = "0";
									    	        }
	    	        
	        		DecimalFormat ft = new DecimalFormat("#.####");
	        		
	        		
	        		String cr1 = (String) credits1.getText();
	        		String cr2 = (String) credits2.getText();
	        		String cr3 = (String) credits3.getText();
	        		String cr4 = (String) credits4.getText();
	        		String cr5 = (String) credits5.getText();
	        		String cr6 = (String) credits6.getText();
	        		String cr7 = (String) credits7.getText();
	        		String cr8 = (String) credits8.getText();
	        		
	        		double c1 = Double.parseDouble(cr1);
	        		double c2 = Double.parseDouble(cr2);
	        		double c3 = Double.parseDouble(cr3);
	        		double c4 = Double.parseDouble(cr4);
	        		double c5 = Double.parseDouble(cr5);
	        		double c6 = Double.parseDouble(cr6);
	        		double c7 = Double.parseDouble(cr7);
	        		double c8 = Double.parseDouble(cr8);
	        		
	        		int w1 = Integer.parseInt(ws1);
	        		int w2 = Integer.parseInt(ws2);
	        		int w3 = Integer.parseInt(ws3);
	        		int w4 = Integer.parseInt(ws4);
	        		int w5 = Integer.parseInt(ws5);
	        		int w6 = Integer.parseInt(ws6);
	        		int w7 = Integer.parseInt(ws7);
	        		int w8 = Integer.parseInt(ws8);
	        		
	        		double q1 = w1 * c1;
	        		double q2 = w2 * c2;
	        		double q3 = w3 * c3;
	        		double q4 = w4 * c4;
	        		double q5 = w5 * c5;
	        		double q6 = w6 * c6;
	        		double q7 = w7 * c7;
	        		double q8 = w8 * c8;
	        		
	        		double tc = c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8;
	        		double tq = q1 + q2 + q3 + q4 + q5 + q6 + q7 + q8;
	        		double nf = tq / tc;
	        		
	        		String af1 = (String) grade1.getSelectionModel().getSelectedItem();
	    	        String as1;
	    	        if(cf1.contains("Honors") || cf1.contains("AP")) {
	    	        	if(af1.equals("A")) {
	    	        		as1 = "5";
	    	        	}else if(af1.equals("B")) {
	    	        		as1 = "4";
	    	        	}else if(af1.equals("C")) {
	    	        		as1 = "3";
	    	        	}else if(af1.equals("D")) {
	    	        		as1 = "2";
	    	        	}else {
	    	        		as1 = "0";
	    	        }
	    	        }else {
	    	        	if(af1.equals("A")) {
		    	        	as1 = "4";
		    	        }else if(af1.equals("B")) {
		    	        	as1 = "3";
		    	        }else if(af1.equals("C")) {
		    	        	as1 = "2";
		    	        }else if(af1.equals("D")) {
		    	        	as1 = "1";
		    	        }else {
		    	        	as1 = "0";
		    	        }
	    	        }
	    	        String af2 = (String) grade2.getSelectionModel().getSelectedItem();
	    	        String as2;
	    	        if(cf2.contains("Honors") || cf2.contains("AP")) {
	    	        	if(af2.equals("A")) {
	    	        		as2 = "5";
	    	        	}else if(af2.equals("B")) {
	    	        		as2 = "4";
	    	        	}else if(af2.equals("C")) {
	    	        		as2 = "3";
	    	        	}else if(af2.equals("D")) {
	    	        		as2 = "2";
	    	        	}else {
	    	        		as2 = "0";
	    	        }
	    	        }else {
	    	        	if(af2.equals("A")) {
		    	        	as2 = "4";
		    	        }else if(af2.equals("B")) {
		    	        	as2 = "3";
		    	        }else if(af2.equals("C")) {
		    	        	as2 = "2";
		    	        }else if(af2.equals("D")) {
		    	        	as2 = "1";
		    	        }else {
		    	        	as2 = "0";
		    	        }
	    	        }
	    	        String af3 = (String) grade3.getSelectionModel().getSelectedItem();
	    	        String as3;
	    	        if(cf3.contains("Honors") || cf3.contains("AP")) {
	    	        	if(af3.equals("A")) {
	    	        		as3 = "5";
	    	        	}else if(af3.equals("B")) {
	    	        		as3 = "4";
	    	        	}else if(af3.equals("C")) {
	    	        		as3 = "3";
	    	        	}else if(af3.equals("D")) {
	    	        		as3 = "2";
	    	        	}else {
	    	        		as3 = "0";
	    	        }
	    	        }else {
	    	        	if(af3.equals("A")) {
		    	        	as3 = "4";
		    	        }else if(af3.equals("B")) {
		    	        	as3 = "3";
		    	        }else if(af3.equals("C")) {
		    	        	as3 = "2";
		    	        }else if(af3.equals("D")) {
		    	        	as3 = "1";
		    	        }else {
		    	        	as3 = "0";
		    	        }
	    	        }
	    	        String af4 = (String) grade4.getSelectionModel().getSelectedItem();
	    	        String as4;
	    	        if(cf4.contains("Honors") || cf4.contains("AP")) {
	    	        	if(af4.equals("A")) {
	    	        		as4 = "5";
	    	        	}else if(af4.equals("B")) {
	    	        		as4 = "4";
	    	        	}else if(af4.equals("C")) {
	    	        		as4 = "3";
	    	        	}else if(af4.equals("D")) {
	    	        		as4 = "2";
	    	        	}else {
	    	        		as4 = "0";
	    	        }
	    	        }else {
	    	        	if(af4.equals("A")) {
		    	        	as4 = "4";
		    	        }else if(af4.equals("B")) {
		    	        	as4 = "3";
		    	        }else if(af4.equals("C")) {
		    	        	as4 = "2";
		    	        }else if(af4.equals("D")) {
		    	        	as4 = "1";
		    	        }else {
		    	        	as4 = "0";
		    	        }
	    	        }
	    	        String af5 = (String) grade5.getSelectionModel().getSelectedItem();
	    	        String as5;
	    	        if(cf5.contains("Honors") || cf5.contains("AP")) {
	    	        	if(af5.equals("A")) {
	    	        		as5 = "5";
	    	        	}else if(af5.equals("B")) {
	    	        		as5 = "4";
	    	        	}else if(af5.equals("C")) {
	    	        		as5 = "3";
	    	        	}else if(af5.equals("D")) {
	    	        		as5 = "2";
	    	        	}else {
	    	        		as5 = "0";
	    	        }
	    	        }else {
	    	        	if(af5.equals("A")) {
		    	        	as5 = "4";
		    	        }else if(af5.equals("B")) {
		    	        	as5 = "3";
		    	        }else if(af5.equals("C")) {
		    	        	as5 = "2";
		    	        }else if(af5.equals("D")) {
		    	        	as5 = "1";
		    	        }else {
		    	        	as5 = "0";
		    	        }
	    	        }
	    	        String af6 = (String) grade6.getSelectionModel().getSelectedItem();
	    	        String as6;
	    	        if(cf6.contains("Honors") || cf6.contains("AP")) {
	    	        	if(af6.equals("A")) {
	    	        		as6 = "5";
	    	        	}else if(af6.equals("B")) {
	    	        		as6 = "4";
	    	        	}else if(af6.equals("C")) {
	    	        		as6 = "3";
	    	        	}else if(af6.equals("D")) {
	    	        		as6 = "2";
	    	        	}else {
	    	        		as6 = "0";
	    	        }
	    	        }else {
	    	        	if(af6.equals("A")) {
		    	        	as6 = "4";
		    	        }else if(af6.equals("B")) {
		    	        	as6 = "3";
		    	        }else if(af6.equals("C")) {
		    	        	as6 = "2";
		    	        }else if(af6.equals("D")) {
		    	        	as6 = "1";
		    	        }else {
		    	        	as6 = "0";
		    	        }
	    	        }
	    	        String af8 = (String) grade8.getSelectionModel().getSelectedItem();
	    	        String as8;
	    	        	if(af8.equals("A")) {
		    	        	as8 = "4";
		    	        }else if(af8.equals("B")) {
		    	        	as8 = "3";
		    	        }else if(af8.equals("C")) {
		    	        	as8 = "2";
		    	        }else if(af8.equals("D")) {
		    	        	as8 = "1";
		    	        }else {
		    	        	as8 = "0";
		    	        }

		        		String cwr1 = (String) credits1.getText();
		        		String cwr2 = (String) credits2.getText();
		        		String cwr3 = (String) credits3.getText();
		        		String cwr4 = (String) credits4.getText();
		        		String cwr5 = (String) credits5.getText();
		        		String cwr6 = (String) credits6.getText();
		        		String cwr8 = (String) credits8.getText();
		        		
		        		double cw1 = Double.parseDouble(cwr1);
		        		double cw2 = Double.parseDouble(cwr2);
		        		double cw3 = Double.parseDouble(cwr3);
		        		double cw4 = Double.parseDouble(cwr4);
		        		double cw5 = Double.parseDouble(cwr5);
		        		double cw6 = Double.parseDouble(cwr6);
		        		double cw8 = Double.parseDouble(cwr8);
		        		
		        		int ww1 = Integer.parseInt(as1);
		        		int ww2 = Integer.parseInt(as2);
		        		int ww3 = Integer.parseInt(as3);
		        		int ww4 = Integer.parseInt(as4);
		        		int ww5 = Integer.parseInt(as5);
		        		int ww6 = Integer.parseInt(as6);
		        		int ww8 = Integer.parseInt(as8);
		        		
		        		double qw1 = ww1 * cw1;
		        		double qw2 = ww2 * cw2;
		        		double qw3 = ww3 * cw3;
		        		double qw4 = ww4 * cw4;
		        		double qw5 = ww5 * cw5;
		        		double qw6 = ww6 * cw6;
		        		double qw8 = ww8 * cw8;
		        		
		        		double twc = cw1 + cw2 + cw3 + cw4 + cw5 + cw6 + cw8;
		        		double twq = qw1 + qw2 + qw3 + qw4 + qw5 + qw6 + qw8;
		        		double nwf = twq / twc;
		        		
		        		String afw = (String) ftweighted.getText();
		        		String afuw = (String) ftunweighted.getText();
		        		
		        		double frw = Double.parseDouble(afw);
		        		double fruw = Double.parseDouble(afuw);
		        		
		        		double fw = ((nwf + frw) / 2);
		        		double fuw = ((nf + fruw) / 2);
		        		
		        		String f = ft.format(fw);
		        		String f1 = ft.format(fuw);
		        		weighted.setText(f);
		        		unWeighted.setText(f1);
	        	}
	        });
	        
			Group root = new Group(course, finalGrade, finalCredits, course1, course2, course3, course4, course5, course6, course7, course8, grade1, grade2, grade3, grade4, grade5, grade6, grade7, grade8, credits1, credits2, credits3, credits4, credits5, credits6, credits7, credits8, calculateGPA, unWeightedGpa, unWeighted, weighted, weightedGpa, fweighted, funweighted, ftweighted, ftunweighted, back);
			Scene scene2 = new Scene(root, 750, 500);
			
			GPACalc.getStage2().setScene(scene2);
			
			s2.show();
		}
	}
	public static Stage getStage1() {
		// TODO Auto-generated method stub
		return s1;
	}
	public static Stage getStage2() {
		// TODO Auto-generated method stub
		return s2;
	}
	public static Stage getStage3() {
		// TODO Auto-generated method stub
		return s3;
	}
	public static Stage getStage4() {
		// TODO Auto-generated method stub
		return s4;
	}
	public static Stage getStage5() {
		// TODO Auto-generated method stub
		return s5;
	}
}